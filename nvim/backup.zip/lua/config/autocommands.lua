vim.api.nvim_create_autocmd("TextYankPost", {
	pattern = "*",
	callback = function()
		vim.highlight.on_yank({ higroup = "IncSearch", timeout = 200 })
	end,
})

vim.api.nvim_create_autocmd("LspAttach", {
	group = vim.api.nvim_create_augroup("my.lsp", {}),
	callback = function(args)
		local client = assert(vim.lsp.get_client_by_id(args.data.client_id))
		-- if client:supports_method('textDocument/implementation') then
		-- 	-- Create a keymap for vim.lsp.buf.implementation ...
		-- end

		if
		    not client:supports_method("textDocument/willSaveWaitUntil")
		    and client:supports_method("textDocument/formatting")
		then
			vim.api.nvim_create_autocmd("BufWritePre", {
				group = vim.api.nvim_create_augroup("my.lsp", { clear = false }),
				buffer = args.buf,
				callback = function()
					vim.lsp.buf.format({ bufnr = args.buf, id = client.id, timeout_ms = 1000 })
				end,
			})
		end
	end,
})

vim.api.nvim_create_user_command("LspInfo", function()
	local clients = vim.lsp.get_clients({ bufnr = 0 })
	if #clients == 0 then
		print("No active LSP clients attached to this buffer.")
		return
	end

	local client_names = {}
	for _, client in ipairs(clients) do
		table.insert(client_names, client.name .. " (id: " .. client.id .. ")")
	end
	print("Active clients: " .. table.concat(client_names, ", "))
end, {})

vim.api.nvim_create_autocmd("FileType", {
	pattern = "typst",
	callback = function()
		vim.opt_local.makeprg = "typst compile %"
	end,
})

vim.api.nvim_create_autocmd("FileType", {
	pattern = "python",
	callback = function()
		vim.opt_local.makeprg = "uv run %"
	end,
})

vim.api.nvim_create_autocmd("FileType", {
	pattern = "go",
	callback = function()
		vim.opt_local.makeprg = "go run %"
	end,
})

vim.api.nvim_create_autocmd("FileType", {
	pattern = { "jsx", "tsx" },
	callback = function()
		vim.opt_local.makeprg = "bun run dev"
	end,
})

vim.api.nvim_create_autocmd("FileType", {
	pattern = "cpp",
	callback = function()
		vim.opt_local.makeprg = "g++ -std=c++20 -Wall -Wextra -o %:r % && ./%:r"
	end,
})
